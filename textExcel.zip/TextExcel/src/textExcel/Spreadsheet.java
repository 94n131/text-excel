//Daniel Gao

package textExcel;

public class Spreadsheet implements Grid{

	Cell[][] sheet;

	public Spreadsheet() { //the constructor
		sheet= new Cell[getRows()][getCols()];//initializes 2d array of empty cells with chosen length and width
		for (int row=0; row<getRows();row++) {
			for (int col=0;col<getCols();col++) {
				 Cell c = new EmptyCell();
				sheet[row][col]= c;
	}	
}
	}
	@Override
	public String processCommand(String command){ //processes the commands from the scanner. 
		

		// TODO Auto-generated method stub
		if(command.equals("")) {
			return "";
		}
		if (command.contains("=")){
			//assign value
		    return doCommand(command);
		}
		if (command.toLowerCase().contains("clear")){
			if (command.toLowerCase().equals("clear")) {
				return cleargrid(command);
			}else {
			// clear one cell
				return clearcell(command);
			}
		  }else {
			  //cell inspect
			return cellInspect(command);
			
		}
	}
	
	//returns the data in a particular cell
	public String cellInspect (String cell) {
		Location loc = new SpreadsheetLocation(cell);
		return (getCell(loc)).fullCellText();
	}
	
	public String doCommand(String command) { //checks and does a command from  specific keywords from user input.
		String[] array=command.split(" ",3);
		Location loc = new SpreadsheetLocation(array[0]);
			Cell s; 
			// if it has "", it is a text cell
			if (array[2].contains("\"")) { 
				s = new textCell(array[2]);
			}
			//if it has %, it is a percent cell
			else if(array[2].contains("%")) {
				s = new percentCell(array[2]);
				
			}
			// if it has (), it is a formula cell
			else if(array[2].contains("(")) {
					s = new formulaCell(array[2], sheet);
			}
			else {
				s = new valueCell(array[2]);
				s.abbreviatedCellText();
			}
			sheet[loc.getRow()][loc.getCol()]=s;
			return getGridText();
			
		}
	
	
	//clears the entire spreadsheet if called upon
	public String cleargrid(String command) {
		for(int row = 0; row< sheet.length;row++) {
			for(int col = 0; col < sheet[0].length; col++) {
				Cell cell = new EmptyCell();
				sheet[row][col] = cell;
			}
		} 
	return getGridText();
  }
	
	
	//clears a specific cell if called upon
  public String clearcell(String command) {
	  String[] split = command.split(" ");
		SpreadsheetLocation loc = new SpreadsheetLocation(split[1]);
		Cell cell = new EmptyCell();
		sheet[loc.getRow()][loc.getCol()] = cell;
		
		return getGridText();
  }
	

	@Override
	public int getRows() //sets number of rows
	{
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public int getCols()//sets number of columns
	{
		// TODO Auto-generated method stub
		return 12;
	}

	@Override
	public Cell getCell(Location loc)
	{   
		return sheet[loc.getRow()][loc.getCol()];
	}


	@Override
	public String getGridText() //prints out the whole 
	{
		 String head = "|";
		String tail = "   |";
		for(int i = 'A'; i < 'A'+ getCols(); i++) {
		     tail += (char) i + "         |";
		}
		String newLine= tail + "\n";
		for(int i = 0; i < getRows(); i++) {
			newLine += (i+1 + "  ").substring(0, 3) + head;
			for(int j = 0; j < getCols(); j++) {
				newLine += (sheet[i][j].abbreviatedCellText() + "          ").substring(0, 10) + head;
			}
		newLine += "\n";
		}
	 return newLine;
}
}
		