//Daniel Gao

package textExcel;

public class percentCell extends RealCell{
	private String original;
	public percentCell(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	public String abbreviatedCellText() {
		String s= (int)(getDoubleValue()* 100) + "%          ";
		return s.substring(0,10);
	}
	
	 public double getDoubleValue() {
	    	String[] arr = getOriginal().split("%");
	    	return Double.parseDouble(arr[0])/100;
	    	
	    }
	// text for individual cell inspection, not truncated or padded
	public String fullCellText() {
		return getDoubleValue() + "";
	}
   
    
}
    

