package textExcel;

public class EmptyCell implements Cell{

	@Override
	public String abbreviatedCellText() {
		// TODO Auto-generated method stub
		return "          "; //10 spaces
	}

	@Override
	public String fullCellText() {
		// TODO Auto-generated method stub
		return "";
	}
	
	public EmptyCell(){
		
	}

}
