//Daniel Gao

package textExcel;

public class valueCell extends RealCell{
	
	public valueCell(String original) {
		super(original);
	}
	public String fullCellText() {
		//inherited from real cell
		return getOriginal();
	}
}