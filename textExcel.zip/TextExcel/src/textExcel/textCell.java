//Daniel Gao
package textExcel;

public class textCell implements Cell{

	private String original;
	// constructor
	public textCell(String original) {
		this.original = original;
	}
	
	public String abbreviatedCellText() {
		String s= original.substring(1,original.length()-1);
		s += "          ";
		return s.substring(0,10);
		
	}
	
	public String fullCellText() {
		return original;
	}
	
}