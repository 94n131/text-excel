//Daniel Gao

package textExcel;

public class formulaCell extends RealCell{ 
	
	Cell [][] arraysheet;
	public formulaCell(String s,Cell[][]arraysheet) {
		super(s);
		this.arraysheet= arraysheet;
	}
	// text for individual cell inspection, not shortened
	public String fullCellText() {
	  return getOriginal();
	}
	
	
	public double getDoubleValue() { // generate a numeric result for an arithmetic formula that does not contain cell references.
    String[] originalArray = getOriginal().split(" ");
		double answer = 0;
		if(originalArray.length == 4) {
	              answer = Sum();
			if(originalArray[1].toLowerCase().equals("avg")) {
				return Avg();
			}	
						
		}else {	
		for(int i = 1; i < originalArray.length; i += 2) { //cycles through every cell until it reaches particluar cell for operations.
			if(originalArray[i].charAt(0) >= 65) {
				Location loc = new SpreadsheetLocation(originalArray[i]);	
				originalArray[i]  = arraysheet[loc.getRow()][loc.getCol()].abbreviatedCellText();
			}
			if(originalArray[i-1].equals("+") || originalArray[i-1].equals("(") ){
				answer += Double.parseDouble(originalArray[i]); // adds
			}
			else if(originalArray[i-1].equals("-")) {
				answer -= Double.parseDouble(originalArray[i]); //subtracts
			}
			else if(originalArray[i-1].equals("*")) {
				answer *= Double.parseDouble(originalArray[i]); //multiplies
			}
			else if(originalArray[i-1].equals("/")) {
				answer /= Double.parseDouble(originalArray[i]); //divides
			}
		}
		}
		return answer;
	}

	
	
	
	public double Sum() {
String[] array = getOriginal().split(" ");
		double answer = 0;
		String[] nums = array[2].split("-");
		Location begin = new SpreadsheetLocation(nums [0]);
		Location end = new SpreadsheetLocation(nums [1]);
		for(int row = begin.getRow(); row <= end.getRow(); row++) {
			for(int col = begin.getCol(); col <= end.getCol(); col++) {
				answer += Double.parseDouble(arraysheet[row][col].abbreviatedCellText());
			}
		}
		return answer;
}
	
	
	
	
	public double Avg() {
		String[] array = getOriginal().split(" ");
		double answer=0;
		int n = 0;
		String[] nums = array[2].split("-");
		Location begin = new SpreadsheetLocation(nums[0]);
		Location end = new SpreadsheetLocation(nums[1]);
		for(int row = begin.getRow(); row <= end.getRow(); row++) {
			for(int col = begin.getCol(); col <= end.getCol(); col++) {
				answer += Double.parseDouble(arraysheet[row][col].abbreviatedCellText());
				n++;
			}
		}
		return answer/n;
	}
}