//Daniel Gao
package textExcel;

import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args)
	{
	    Scanner Console = new Scanner(System.in);
	    Spreadsheet sheet = new Spreadsheet();
	    System.out.println("Enter a Command: ");
	    String command  = Console.nextLine();
	    
	    while(!command.equalsIgnoreCase("quit")) {
	    	System.out.println(sheet.processCommand(command));
	    	System.out.println("Enter a command: ");
	    	command = Console.nextLine();
	    }
	    Console.close();
	}
}
