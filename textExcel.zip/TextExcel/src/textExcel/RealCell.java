//Daniel Gao

package textExcel;

public class RealCell implements Cell{
	private String original;
	// constructor
	public RealCell(String s) {
		original =s;
	}
	public String abbreviatedCellText() {
		String s=getDoubleValue()+ "         ";
		return s.substring(0,10);
	}
	public String fullCellText() {
		String s= getOriginal()+ "          ";
		return s.substring(0,10);
	}
	 public double getDoubleValue() {
		 return Double.parseDouble(original);
	    }
	 public String getOriginal() {
		 return original;
	 }
	 
	 
}

