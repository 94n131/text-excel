package textExcel;

//Update this file with your own code.

public class SpreadsheetLocation implements Location
{
	private int row;
	private int col;
	
    @Override
    public int getRow()
    {
        // TODO Auto-generated method stub
        return row;
    }

    @Override
    public int getCol()
    {
        // TODO Auto-generated method stub 
        return col;
    }
    
    public SpreadsheetLocation(String loc)
    {
        loc = loc.toUpperCase();
        char letter = loc.charAt(0);//uses ascii code so that it can list letters in order
        col = letter-65;
        String rowStr = loc.substring(1);
        row = Integer.parseInt(rowStr)-1;
    }

}
